me = {
    "f_name": "Eduardo",
    "l_name": "Reynoso Rosales",
    "color": "black",
    "hobbies": [],
    "address": {"number": 147, "street": "Vets", "city": "Tijuana"},
}

catalog = [
    {
        "_id": "1",
        "title": "Air Jordan 1",
        "price": 120,
        "brand": "Nike",
        "category": "Basketball shoes",
        # "image": "./images/jordans.png"
    },
    
    {
        "_id": "2",
        "title": "Nike LeBron 19",
        "price": 110,
        "brand": "Nike",
        "category": "Basketball shoes",
        # "image": "./images/lebrons.png"
    },

    {
        "_id": "3",
        "title": "Nike Kyrie 8",
        "price": 130,
        "brand": "Nike",
        "category": "Basketball shoes",
        # "image": "./images/kyrie.png"
    },

    {
        "_id": "4",
        "title": "Adidas Predator Edge",
        "price": 120,
        "brand": "Adidas",
        "category": "Soccer shoes",
        # "image": "./images/adidas.png"
    },
]


